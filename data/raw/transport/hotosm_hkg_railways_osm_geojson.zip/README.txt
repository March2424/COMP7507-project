oex export
==========

Generated:        2026-11-03 21:21:24 UTC
oex version:      0.4.19
Project:          https://github.com/osgeonepal/oex

Country (ISO3):   HKG
Boundary:         user-provided (buffered +10000m, simplified 1000m)
Bounding box:     (113.7413, 22.0870, 114.4982, 22.6464)

Dataset:          railways
Format:           GeoJSON (geojson)
Features:         1,640

Source:           OpenStreetMap contributors
Source URL:       https://www.openstreetmap.org/
Snapshot:         2026-11-03
License:          Open Database License (ODC-ODbL)
License URL:      https://opendatacommons.org/licenses/odbl/1-0/

About the source
  OpenStreetMap is a community-edited geographic dataset of the world. Country
  features are extracted from the source PBF via quackosm with the union of
  all category tag filters; per-category exports apply tag predicates at query
  time.

Notes
  - GeoJSON is a single-file text format. Consider gpkg for very large layers.

Feedback:         https://github.com/osgeonepal/oex/issues
Engine: planet